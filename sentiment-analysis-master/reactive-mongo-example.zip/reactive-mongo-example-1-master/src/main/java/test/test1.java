package test;

import java.util.stream.Stream;
import java.util.*;
public class test1 {
	public static void main(String[] args)
    {
		/*
        Stream<Integer> stream = Stream.of(1,2,3,4,5,6,7,8,9);
        
        stream.forEach(p -> {if(p%2 == 0 )
        	{
        		System.out.println(p);}
        	});
        	*/
		
    }
}
